import { getDatabase } from '@netlify/database';

const json = (statusCode, body) => new Response(JSON.stringify(body), {
  status: statusCode,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
});
const clean = (v, max = 500) => String(v ?? '').trim().slice(0, max);

export default async (request) => {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' } });
  try {
    const db = getDatabase();
    if (request.method === 'POST') {
      let body;
      try { body = await request.json(); } catch { return json(400, { error: 'Dados do pedido inválidos.' }); }
      const customer = clean(body.customer, 120);
      const service = body.service === 'Entrega' ? 'Entrega' : 'Retirada no local';
      const payment = clean(body.payment, 40);
      const items = Array.isArray(body.items) ? body.items.slice(0, 80).map(i => ({
        id: clean(i.id, 100), name: clean(i.name, 160), quantity: Math.max(1, Math.min(99, Number(i.quantity) || 1)),
        unitPrice: Math.max(0, Number(i.unitPrice) || 0), detail: clean(i.detail, 200)
      })) : [];
      const subtotal = Number(body.subtotal), deliveryFee = Number(body.deliveryFee), total = Number(body.total);
      if (!customer || !payment || !items.length || !Number.isFinite(total) || total < 0 || total > 100000) return json(400, { error: 'Confira o nome, pagamento, itens e total do pedido.' });
      if (items.some(i => !i.name || !Number.isFinite(i.unitPrice) || i.unitPrice > 10000)) return json(400, { error: 'Um dos itens do pedido é inválido.' });
      const rows = await db.sql`
        INSERT INTO planets_orders (customer, service, address, neighborhood, payment, pix_status, change_needed, change_amount, notes, items, subtotal, delivery_fee, total, whatsapp_message, status)
        VALUES (${customer}, ${service}, ${clean(body.address, 300)}, ${clean(body.neighborhood, 120)}, ${payment}, ${clean(body.pixStatus, 60)}, ${clean(body.changeNeeded, 20)}, ${clean(body.changeAmount, 40)}, ${clean(body.notes, 1000)}, ${JSON.stringify(items)}::jsonb, ${Number.isFinite(subtotal) ? subtotal : 0}, ${Number.isFinite(deliveryFee) ? deliveryFee : 0}, ${total}, ${clean(body.whatsappMessage, 6000)}, 'Recebido')
        RETURNING id, created_at
      `;
      return json(201, { ok: true, id: rows[0].id, createdAt: rows[0].created_at });
    }
    if (request.method === 'GET') {
      const expected = process.env.NETLIFY_ADMIN_PASSWORD;
      const auth = request.headers.get('authorization') || '';
      const supplied = auth.startsWith('Bearer ') ? auth.slice(7) : '';
      if (!expected || supplied.length < 8 || supplied !== expected) return json(401, { error: 'Acesso administrativo não autorizado. Confira a variável NETLIFY_ADMIN_PASSWORD no Netlify.' });
      const rows = await db.sql`SELECT id, created_at, customer, service, payment, items, subtotal, delivery_fee, total, notes, status FROM planets_orders ORDER BY created_at DESC LIMIT 500`;
      return json(200, { orders: rows.map(r => ({ id: r.id, date: new Date(r.created_at).toLocaleString('pt-BR'), customer: r.customer, delivery: r.service, payment: r.payment, items: r.items, subtotal: Number(r.subtotal), deliveryFee: Number(r.delivery_fee), amount: Number(r.total), notes: r.notes, status: r.status })) });
    }
    return json(405, { error: 'Método não permitido.' });
  } catch (error) {
    console.error('Falha na API de pedidos:', error?.message || error);
    return json(500, { error: 'Não foi possível acessar o banco de pedidos. Confira se a migração foi aplicada na publicação.' });
  }
};
