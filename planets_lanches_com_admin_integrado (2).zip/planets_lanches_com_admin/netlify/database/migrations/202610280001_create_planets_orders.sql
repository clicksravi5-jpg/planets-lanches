CREATE TABLE IF NOT EXISTS planets_orders (
  id BIGSERIAL PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  customer TEXT NOT NULL,
  service TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  neighborhood TEXT NOT NULL DEFAULT '',
  payment TEXT NOT NULL,
  pix_status TEXT NOT NULL DEFAULT '',
  change_needed TEXT NOT NULL DEFAULT '',
  change_amount TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  delivery_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  whatsapp_message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Recebido'
);
CREATE INDEX IF NOT EXISTS planets_orders_created_at_idx ON planets_orders (created_at DESC);
